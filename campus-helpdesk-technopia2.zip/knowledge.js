// knowledge.js — THE ONLY SOURCE OF TRUTH
// Every fact below is copied verbatim from the TECHNOPIA 2.0 problem
// statement (Section 3, Sample University Information).
// The AI engine may ONLY answer from this file. Nothing else is a fact.
// If a question needs a fact that is not here, the engine must say so.
//
// Sample competition data — not an official statement of university regulations.

const KNOWLEDGE_BASE = [
  {
    id: "academics",
    category: "Academics",
    title: "Academic help",
    fact: "Students may contact their faculty advisor for academic-related assistance.",
    keywords: ["academic", "academics", "faculty", "advisor", "adviser", "teacher", "professor", "subject", "course", "study", "help", "guidance", "mentor", "problem", "issue", "doubt", "class", "lesson"],
    phrases: ["academic problem", "academic help", "faculty advisor", "who to contact for academics"]
  },
  {
    id: "attendance",
    category: "Attendance",
    title: "Attendance requirement",
    fact: "Students should follow the minimum attendance requirement prescribed by university regulations.",
    keywords: ["attendance", "attend", "minimum", "requirement", "regulation", "regulations", "percent", "percentage", "shortage", "low attendance"],
    phrases: ["attendance requirement", "minimum attendance", "attendance percentage"]
  },
  {
    id: "examinations",
    category: "Examinations",
    title: "Examination timetable & notifications",
    fact: "Examination timetables and notifications are published through official university channels.",
    keywords: ["exam", "exams", "examination", "examinations", "timetable", "time table", "schedule", "notification", "notifications", "hall ticket", "date sheet", "exam schedule"],
    phrases: ["examination timetable", "exam timetable", "where is the timetable", "exam notification"]
  },
  {
    id: "placements",
    category: "Placements",
    title: "Placements & training",
    fact: "Students may contact the Placement Department for training and placement-related information.",
    keywords: ["placement", "placements", "training", "job", "jobs", "interview", "company", "companies", "career", "recruit", "recruitment", "internship", "drive"],
    phrases: ["placement training", "placement department", "placement help"]
  },
  {
    id: "library",
    category: "Library",
    title: "Library resources",
    fact: "Students may access library resources according to the library's timings and regulations.",
    keywords: ["library", "book", "books", "resource", "resources", "borrow", "return", "reading", "timing", "timings", "hours", "open"],
    phrases: ["library timings", "library resources", "borrow a book"]
  },
  {
    id: "hostel",
    category: "Hostel",
    title: "Hostel complaints",
    fact: "Hostel-related complaints should be submitted to the Hostel Administration.",
    keywords: ["hostel", "complaint", "complaints", "mess", "food", "room", "warden", "accommodation", "stay", "pg", "dorm"],
    phrases: ["hostel complaint", "raise a hostel complaint", "hostel administration"]
  },
  {
    id: "administration",
    category: "Administration",
    title: "Certificates & student records",
    fact: "Students may contact the respective administrative office for certificates and student records.",
    keywords: ["administration", "admin", "certificate", "certificates", "record", "records", "document", "documents", "transcript", "bonafide", "office", "id card"],
    phrases: ["certificate", "student records", "administrative office"]
  },
  {
    id: "events",
    category: "Events",
    title: "University events",
    fact: "University event announcements are shared through official communication channels.",
    keywords: ["event", "events", "fest", "cultural", "announcement", "announcements", "program", "programme", "workshop", "seminar", "celebration"],
    phrases: ["university events", "event announcements"]
  }
];

// Synonyms the AI expands before matching — so "exam" and "examination"
// or "timetable" and "schedule" are understood as the same idea.
const SYNONYMS = {
  exam: "examination", exams: "examination",
  timetable: "schedule", timetables: "schedule",
  advisor: "advisor", adviser: "advisor",
  hostel: "hostel", hostels: "hostel",
  placement: "placement", placements: "placement",
  library: "library", libraries: "library",
  certificate: "certificate", certificates: "certificate",
  complaint: "complaint", complaints: "complaint",
  event: "event", events: "event",
  job: "placement", jobs: "placement",
  teacher: "faculty", professor: "faculty",
  book: "library", books: "library"
};

const STOPWORDS = new Set(("a an the is are was were do does did can could will would should shall may might i me my we our you your he she it they them his her their this that these those what where when who whom how why which in on at to for of from with by about as and or but if then so please tell me give show find get know need want").split(" "));

// Export for browser + Node (so the engine can be unit-tested)
if (typeof module !== "undefined" && module.exports) {
  module.exports = { KNOWLEDGE_BASE, SYNONYMS, STOPWORDS };
}
