// app.js — UI wiring only. All understanding lives in ai-engine.js.
// Optional LLM hook: if you later add a backend at /api/chat (key in an
// env var on the server, NEVER in this file), enhanceWithLLM() may
// rephrase the grounded answer. It may never add new facts. Without a
// backend, the local engine is the whole AI — and the app works offline.

const $ = s => document.querySelector(s);
const messagesEl = $("#messages");
const inputEl = $("#input");
const sendBtn = $("#send");

const EXAMPLES = [
  "Whom should I contact for academic problems?",
  "Where can I find the examination timetable?",
  "Whom should I contact for placement training?",
  "How can I raise a hostel complaint?",
  "What is the exact date of my next examination?"
];

function esc(s){ return s.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); }

function addMessage(text, who, analysis){
  const div = document.createElement("div");
  div.className = "msg " + who;
  div.innerHTML = esc(text);
  if (who === "ai" && analysis){
    const pct = Math.round(analysis.confidence * 100);
    const meta = document.createElement("div");
    meta.className = "meta";
    const src = analysis.source ? `<span class="chip src">📚 Source: ${esc(analysis.source)}</span>` : `<span class="chip src">📚 Source: supplied information — no match</span>`;
    const conf = analysis.decision === "greeting" || analysis.decision === "thanks"
      ? `<span class="chip">💬 General</span>`
      : `<span class="chip conf">🤖 AI confidence: ${pct}%</span><span class="chip">Intent: ${esc(analysis.category || "unknown")}</span>`;
    meta.innerHTML = src + conf +
      (analysis.matchedKeywords && analysis.matchedKeywords.length ? `<span class="chip">Keywords: ${esc(analysis.matchedKeywords.slice(0,4).join(", "))}</span>` : "") +
      (analysis.decision === "unknown" || analysis.decision === "unknown-specific" ? `<span class="chip" style="color:#b91c1c">⚠️ Not invented — stated as unavailable</span>` : "");
    if (analysis.decision !== "greeting" && analysis.decision !== "thanks"){
      const bar = document.createElement("div");
      bar.className = "confbar"; bar.innerHTML = `<i style="width:${pct}%"></i>`;
      meta.appendChild(bar);
    }
    div.appendChild(meta);
  }
  messagesEl.appendChild(div);
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

async function enhanceWithLLM(groundedAnswer, question){
  // No backend configured in this submission -> return null, local answer stands.
  // To enable: deploy a tiny backend that reads OPENAI_API_KEY / GEMINI_API_KEY
  // from env, calls the model with ONLY the grounded fact as context, and
  // returns a rephrasing. Never put a key in frontend code.
  return null;
}

async function ask(question){
  const q = (question || "").trim();
  if (!q) return;
  addMessage(q, "user");
  inputEl.value = "";
  const typing = document.createElement("div");
  typing.className = "typing"; typing.textContent = "AI is reading the supplied information…";
  messagesEl.appendChild(typing);
  messagesEl.scrollTop = messagesEl.scrollHeight;

  // Small delay so the "thinking" state is visible in the demo
  await new Promise(r => setTimeout(r, 450));

  let result;
  try {
    result = CampusAI.generateResponse(q);
    const enhanced = await enhanceWithLLM(result.answer, q);
    if (enhanced) result = { ...result, answer: enhanced };
  } catch (err){
    console.error(err);
    result = { answer: "Sorry — something went wrong while reading your question. Please try again, or rephrase it.", decision: "unknown", confidence: 0, source: null, category: null, matchedKeywords: [] };
  }
  typing.remove();
  addMessage(result.answer, "ai", result);
}

function fillExamples(){
  const wrap = $("#suggestions");
  EXAMPLES.forEach(ex => {
    const b = document.createElement("button");
    b.className = "sugg"; b.type = "button"; b.textContent = ex;
    b.onclick = () => ask(ex);
    wrap.appendChild(b);
  });
  document.querySelectorAll(".cat").forEach(btn => {
    btn.onclick = () => {
      const map = {
        academics: "Whom should I contact for academic problems?",
        examinations: "Where can I find the examination timetable?",
        placements: "Whom should I contact for placement training?",
        hostel: "How can I raise a hostel complaint?",
        library: "What are the library timings and regulations?",
        administration: "Whom should I contact for certificates and student records?",
        attendance: "What is the minimum attendance requirement?",
        events: "Where are university event announcements shared?"
      };
      ask(map[btn.dataset.cat] || btn.textContent);
    };
  });
}

sendBtn.onclick = () => ask(inputEl.value);
inputEl.addEventListener("keydown", e => { if (e.key === "Enter") ask(inputEl.value); });

fillExamples();
addMessage("Hello! I'm the Campus Helpdesk AI for Presidency University. Ask me about academics, examinations, placements, hostel, library, administration, attendance or events — I'll answer only from the supplied university information, and I'll tell you clearly if something isn't in it.", "ai", { decision: "greeting", confidence: 1, source: null, category: null, matchedKeywords: [] });
inputEl.focus();
