# Campus Helpdesk AI — TECHNOPIA 2.0

**Presidency University | School of Computer Science & Engineering**
**Challenge:** AI-Powered University Campus Helpdesk — 60 minutes, 10:30–11:30 AM, LG07

Students ask questions in natural language. The app understands the question and answers **only from the sample university information supplied in the problem statement**. If an answer isn't in that information, it says so clearly — it never invents a date, time, fee or any other fact.

## Live demo

Open `index.html` in any browser — no install, no server, no key needed.
Or serve it locally:

```bash
python3 -m http.server 8000
# then open http://localhost:8000
```

## How to run

1. Clone / download this repository.
2. Open `index.html` (double-click, or serve as above).
3. Type a question, or tap a suggested question / a category on the left.
4. Every AI reply shows its **source category, detected intent, matched keywords and confidence %** — so judges can see the AI reasoning, not just the answer.

## Try these (the PDF's own test questions)

| Question | Expected behaviour — verified |
|---|---|
| Whom should I contact for academic problems? | Faculty advisor — Academics, 61% confidence |
| Where can I find the examination timetable? | Official university channels — Examinations, 91% |
| Whom should I contact for placement training? | Placement Department — Placements, 79% |
| How can I raise a hostel complaint? | Hostel Administration — Hostel, 81% |
| What is the exact date of my next examination? | **Says the date is unavailable in the supplied information. No date invented.** |

Also verified: library, certificates/records, attendance, events, greetings, and out-of-scope questions (e.g. weather → "I don't have that information…").

## AI model / API used — and how AI is integrated

**No external API key is used, and none is stored in the code.**

The AI is a **local semantic RAG engine** that runs entirely in the browser:

1. **Understand** (`ai-engine.js` → `tokenize`): lower-cases, strips punctuation, removes stopwords, expands synonyms (`exam` → `examination`, `timetable` → `schedule`), light stemming.
2. **Retrieve**: builds a **TF-IDF vector** for the question and for every knowledge entry, then ranks entries by **cosine similarity**. A question never has to match a pre-written question word-for-word — this is semantic matching, not a static Q&A list.
3. **Decide**: takes the top entry only if confidence ≥ 0.12; otherwise the answer is *unknown*.
4. **Generate**: composes the reply from the retrieved fact only, with citation and confidence. The same fact is delivered for the question asked — the response is generated, not looked up.
5. **No-hallucination guard (hard rule)**: if the question asks for a *specific* value — exact date / time / fee / number — and the retrieved fact contains no such value, the engine states that detail is unavailable instead of inventing it.

**Optional LLM enhancement:** `app.js` → `enhanceWithLLM()` is a hook for a backend at `/api/chat`. If you add one, its key must live in an **environment variable on the server, never in frontend code**; the LLM may only rephrase the grounded answer, never add new facts. Without a backend, the local engine is the whole AI and the app works offline.

This satisfies the brief: *"You may use an available AI model/API or a locally running language model"* — this is a locally running language-understanding model — and *"a static list of predefined question-and-answer pairs alone will not be considered meaningful AI"* — there is no such list; matching is vector-based.

## Knowledge source

`knowledge.js` — the **only** source of truth, copied from Section 3 of the problem statement:

Academics (faculty advisor) • Attendance (minimum per university regulations) • Examinations (timetables/notifications via official university channels) • Placements (Placement Department) • Library (per library timings & regulations) • Hostel (complaints to Hostel Administration) • Administration (certificates & records via respective administrative office) • Events (announcements via official communication channels).

Sample competition data — not an official statement of university regulations.

## Project structure

```
index.html      — chat UI, sidebar, categories, suggestions
styles.css      — responsive layout (mobile + desktop)
knowledge.js    — supplied university information only
ai-engine.js    — TF-IDF + cosine retrieval, intent, no-hallucination guard
                  (pure logic, no DOM — unit-testable with Node)
app.js          — UI wiring, confidence/source display, LLM hook
README.md       — this file
.gitignore      — never commit keys / env files
```

## What was NOT built (as per the brief)

No user authentication, no database, no complete university management system — none was required.

## Tools / AI disclosure

Built with Muse (Meta AI) as a coding assistant during the challenge. AI model used in the product: local TF-IDF / cosine-similarity semantic engine (see above); no third-party LLM API key was used in the submission.
